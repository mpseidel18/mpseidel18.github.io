# Webcam Theremin

## 1. Introduction and Conceptual Overview

**Core Concept**
Webcam Theremin is an interactive digital instrument that translates real-time hand movements into synthesized music. Utilizing computer vision, it tracks the position of the user's index finger through a standard webcam. The horizontal axis (X) controls pitch, logarithmically mapped and quantized to musical scales, while the vertical axis (Y) controls the volume.

**The Rendering Path**
The application pipeline operates in a continuous, three-step loop:
1. **Frame Capture & Tracking:** The system retrieves the latest frame from the webcam, mirrors it for intuitive interaction, and processes it through MediaPipe's neural networks to isolate hand landmarks.
2. **Mathematical Mapping & Quantization:** The index finger's coordinates are extracted. The X-coordinate is mapped logarithmically to a frequency range and then quantized to the nearest note in the currently selected Major scale. The Y-coordinate is inverted and mapped linearly to control volume.
3. **Audio Synthesis & HUD Overlay:** The resulting frequency and volume targets are sent to an asynchronous audio synthesizer that smoothly glides the oscillator to the new parameters. Simultaneously, the visual grid, UI components, and hand trailing effects are composited over the live video feed.

**Overview**

**What it does:**
*   Synthesizes live audio waveforms (Sine, Triangle, Sawtooth, Square) based on hand position.
*   Enforces musicality by snapping continuous frequencies into playable notes within a selected Major scale.
*   Provides a visual interface (HUD) with a dynamic note grid, real-time parameter feedback, and a Circle of Fifths dial.
*   Features an optional "Gate Mode" that requires the Spacebar to be held down to trigger sound, simulating the physical act of playing a note.

**How it does it:**
*   Uses **OpenCV** to manage webcam hardware access, frame manipulation, and drawing the graphical user interface.
*   Leverages **MediaPipe Tasks Vision** for robust, real-time skeletal hand tracking on the CPU.
*   Employs **SoundDevice** and **NumPy** to run a continuous, high-priority audio callback thread that mathematically generates waveform arrays block-by-block.

---

## 2. Component Deep-Dives (The "1.x" Sections)

### 1. `webcam_theremin.py` (Main Application Logic)
This file houses the central `main()` loop and coordinates the interaction between the webcam, the UI, and the synthesizer.

*   **HUD and Grid Creation:** Calculates dynamic vertical lines that correspond to valid musical notes in the active scale and overlays glassmorphism-style UI panels displaying system status.
*   **Mathematical mapping for pitch calculation:** The X position is normalized (0.0 to 1.0) and transformed logarithmically between `PITCH_MIN` (110 Hz) and `PITCH_MAX` (880 Hz). `quantize_frequency()` then snaps this raw frequency to the nearest valid MIDI note in the current key.

### 1.1 Hand and signal flow in code
A step-by-step sequence of runtime events per frame:
1. `cap.read()` fetches the frame from the camera.
2. The frame is converted to RGB and passed to `landmarker.detect_for_video()`.
3. If a hand is found, landmark `[8]` (Index Finger Tip) is extracted.
4. X and Y coordinates are clamped between 0 and 1.
5. X is converted to frequency; Y is converted to target volume.
6. The `target_freq` and `target_vol` are pushed to the `synth` object.
7. User keyboard inputs are processed (Waveform toggling, Key shifts).
8. The final composited frame is pushed to the screen via `cv2.imshow()`.

### 1.2 `AudioSynthesizer` (Playback Layer)
Details the process of synthesizing and scheduling audio generation.
*   **Asynchronous Audio Thread:** Uses `sounddevice.OutputStream` to spin up a background thread that continuously fires a `callback` function requesting audio blocks.
*   **Phase-Continuous Generation:** To prevent audio popping and clicking when frequencies change rapidly, the synth calculates a vectorized linear frequency sweep using `np.arange`, ensuring continuous phase progression (`phi`) across the audio block.
*   **Smooth Volume Interpolation:** Uses `np.linspace` to glide between the previous frame's volume and the new target volume, creating a natural envelope.

### 1.3 Computer Vision & UI Engine (Drawing Engine)
Explains the low-level visual processing handled by OpenCV.
*   **Motion Trail:** Stores previous hand positions in a `collections.deque` and iterates through them to draw fading, semi-transparent circles.
*   **Circle of Fifths Dial:** Uses trigonometric math (`math.cos` and `math.sin`) to arrange the 12 musical keys in a circular pattern, dynamically highlighting the active scale and its relative minor.

---

## 3. Project Dependencies and Navigation

**External libraries used**
*   **`opencv-python`**: Used for video capture, image processing, and rendering the HUD interface.
*   **`mediapipe`**: Google's machine learning framework, specifically utilizing the Hand Landmarker task model for real-time skeletal tracking.
*   **`sounddevice`**: Provides bindings to the PortAudio library to deliver low-latency audio stream callbacks.
*   **`numpy`**: Powers the heavy mathematical lifting and array manipulation required to generate oscillator waveforms in real-time.

**Code references**
*   `webcam_theremin.py`: The monolithic application script containing all logic, UI drawing, and audio synthesis classes.
*   `requirements.txt`: Python dependencies required to run the environment.
*   `hand_landmarker.task`: The downloaded MediaPipe neural network weights used for tracking.

---

## 4. Implementation Guide

**Practical setup summary**
1. **Prepare Environment:** Ensure you have Python installed on your system.
2. **Install Dependencies:** Open a terminal in the project directory and run `pip install -r requirements.txt`.
3. **Hardware Setup:** Ensure a webcam is connected and a default audio output device (speakers or headphones) is active.
4. **Run Application:** Execute `python webcam_theremin.py` in your terminal. The script will automatically download the `hand_landmarker.task` model file on its first run if it is missing.
5. **Play:** Place your hand in view of the camera. Hold the `Spacebar` and move your index finger left/right for pitch, and up/down for volume.

**Notes**
*   **Environmental Lighting:** MediaPipe relies heavily on contrast. A well-lit room will result in much smoother tracking and less jitter in the audio.
*   **Audio Limits:** The maximum output volume is hard-capped via `MAX_VOLUME_GAIN` to prevent clipping and ear damage when generating pure waveforms.
*   **Initial Freezes on Windows:** The script forces `cv2.CAP_DSHOW` (DirectShow) on Windows systems to bypass common OpenCV initialization freezes with certain webcam drivers.
*   **Keyboard Handling:** To ensure the Spacebar "gate" functions correctly without freezing the UI, the script relies on raw Windows API calls (`ctypes.windll.user32.GetAsyncKeyState`) instead of OpenCV's `waitKey`.
