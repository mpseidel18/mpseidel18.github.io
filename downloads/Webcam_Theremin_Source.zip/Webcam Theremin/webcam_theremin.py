import cv2
import mediapipe as mp
import numpy as np
import sounddevice as sd
import math
import collections
import sys
import os
import urllib.request
import time
import argparse
import ctypes

# ---------------------------------------------------------
# CONSTANTS & CONFIGURATION
# ---------------------------------------------------------
WINDOW_NAME = "Webcam Theremin"
SAMPLE_RATE = 44100
BLOCK_SIZE = 512
PITCH_MIN = 110.0   # A2
PITCH_MAX = 880.0   # A5
SMOOTH_FACTOR = 0.15 # Volume param smoothing factor in main loop
MAX_VOLUME_GAIN = 0.3 # Limit maximum volume to prevent ear damage
TRAIL_LENGTH = 20

# ---------------------------------------------------------
# CIRCLE OF FIFTHS CONFIGURATION
# ---------------------------------------------------------
# Keys arranged clockwise in fifths (7 semitones step)
CIRCLE_OF_FIFTHS = [
    {'key': 'C',  'name': 'C Major / A minor',  'pitch_class': 0},
    {'key': 'G',  'name': 'G Major / E minor',  'pitch_class': 7},
    {'key': 'D',  'name': 'D Major / B minor',  'pitch_class': 2},
    {'key': 'A',  'name': 'A Major / F# minor', 'pitch_class': 9},
    {'key': 'E',  'name': 'E Major / C# minor', 'pitch_class': 4},
    {'key': 'B',  'name': 'B Major / G# minor', 'pitch_class': 11},
    {'key': 'F#', 'name': 'F# Major / D# minor', 'pitch_class': 6},
    {'key': 'C#', 'name': 'C# Major / A# minor', 'pitch_class': 1},
    {'key': 'G#', 'name': 'G# Major / F minor',  'pitch_class': 8},
    {'key': 'D#', 'name': 'D# Major / G minor',  'pitch_class': 3},
    {'key': 'A#', 'name': 'A# Major / C minor',  'pitch_class': 10},
    {'key': 'F',  'name': 'F Major / D minor',   'pitch_class': 5}
]

KEY_ALIASES = {
    'C': 'C', 'C#': 'C#', 'DB': 'C#', 'D-FLAT': 'C#',
    'D': 'D', 'D#': 'D#', 'EB': 'D#', 'E-FLAT': 'D#',
    'E': 'E', 'F': 'F',
    'F#': 'F#', 'GB': 'F#', 'G-FLAT': 'F#',
    'G': 'G', 'G#': 'G#', 'AB': 'G#', 'A-FLAT': 'G#',
    'A': 'A', 'A#': 'A#', 'BB': 'A#', 'B-FLAT': 'A#',
    'B': 'B'
}

# Major scale intervals relative to the root note
MAJOR_INTERVALS = [0, 2, 4, 5, 7, 9, 11]

# Playable MIDI range corresponding to A2 (45) to A5 (81)
MIDI_MIN = 45
MIDI_MAX = 81

# ---------------------------------------------------------
# HELPER FUNCTIONS
# ---------------------------------------------------------
def freq_to_note(freq):
    """Convert frequency to closest musical note name."""
    if freq <= 0:
        return "N/A"
    # MIDI 69 is A4 (440Hz)
    midi = 12 * math.log2(freq / 440.0) + 69
    midi_round = round(midi)
    notes = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]
    note = notes[midi_round % 12]
    octave = (midi_round // 12) - 1
    return f"{note}{octave}"

def get_scale_notes(root_pitch_class):
    """Generate all valid MIDI note numbers for the major scale of the root key within playable range."""
    scale_notes = []
    # Loop over octaves from 2 to 7 to guarantee covering MIDI range [45, 81] for any key
    for octave in range(2, 8):
        for interval in MAJOR_INTERVALS:
            note = 12 * octave + root_pitch_class + interval
            if MIDI_MIN <= note <= MIDI_MAX:
                scale_notes.append(note)
    return sorted(list(set(scale_notes)))

def quantize_frequency(freq, root_pitch_class):
    """Snap the continuous frequency to the nearest note in the active major scale."""
    scale_notes = get_scale_notes(root_pitch_class)
    if not scale_notes:
        return freq
        
    # Convert input frequency to fractional MIDI note
    midi = 12 * math.log2(freq / 440.0) + 69
    
    # Find the closest MIDI note in the scale list
    closest_midi = min(scale_notes, key=lambda n: abs(n - midi))
    
    # Convert back to frequency
    quantized_freq = 440.0 * (2.0 ** ((closest_midi - 69) / 12.0))
    return quantized_freq

# ---------------------------------------------------------
# AUDIO SYNTHESIS CLASS
# ---------------------------------------------------------
class AudioSynthesizer:
    def __init__(self, samplerate=SAMPLE_RATE, blocksize=BLOCK_SIZE):
        self.samplerate = samplerate
        self.blocksize = blocksize
        self.frequency = 440.0      # target frequency
        self.volume = 0.0          # target volume (0.0 to 1.0)
        self.current_frequency = 440.0
        self.current_volume = 0.0
        self.current_phase = 0.0
        self.waveform = 'sine'      # 'sine', 'triangle', 'sawtooth', 'square'
        self.is_muted = False
        self.stream = None

    def callback(self, outdata, frames, time_info, status):
        """Audio callback running on high-priority audio thread."""
        if status:
            pass

        # If muted, or if volume is fully zero (and current is zero), output silence
        if self.is_muted or (self.current_volume == 0.0 and self.volume == 0.0):
            outdata.fill(0)
            self.current_frequency = self.frequency
            self.current_volume = self.volume
            return

        target_freq = self.frequency
        target_vol = self.volume

        # Time step vectors
        T = frames / self.samplerate
        t = np.arange(frames) / self.samplerate

        # Vectorized linear frequency sweep to ensure continuous phase
        f_start = self.current_frequency
        f_end = target_freq
        
        # phi(t) = 2 * pi * \int_{0}^{t} (f_start + (f_end - f_start) * x / T) dx
        phi = 2.0 * np.pi * (f_start * t + 0.5 * (f_end - f_start) * (t ** 2) / T) + self.current_phase

        # Waveform generation
        if self.waveform == 'sine':
            wave = np.sin(phi)
        elif self.waveform == 'triangle':
            wave = (2.0 / np.pi) * np.arcsin(np.sin(phi))
        elif self.waveform == 'sawtooth':
            wave = (phi % (2.0 * np.pi)) / np.pi - 1.0
        elif self.waveform == 'square':
            wave = np.sign(np.sin(phi))
        else:
            wave = np.sin(phi)

        # Smooth volume transition
        v_start = self.current_volume
        v_end = target_vol
        volumes = np.linspace(v_start, v_end, frames)

        # Scale by MAX_VOLUME_GAIN to ensure comfortable listening levels
        outdata[:, 0] = volumes * wave * MAX_VOLUME_GAIN

        # Save state for the next frame
        self.current_phase = (self.current_phase + 2.0 * np.pi * 0.5 * (f_start + f_end) * T) % (2.0 * np.pi)
        self.current_frequency = target_freq
        self.current_volume = target_vol

    def start(self):
        """Start the audio stream."""
        self.stream = sd.OutputStream(
            channels=1,
            callback=self.callback,
            samplerate=self.samplerate,
            blocksize=self.blocksize
        )
        self.stream.start()

    def stop(self):
        """Stop the audio stream."""
        if self.stream:
            self.stream.stop()
            self.stream.close()

    def toggle_waveform(self):
        waveforms = ['sine', 'triangle', 'sawtooth', 'square']
        idx = waveforms.index(self.waveform)
        self.waveform = waveforms[(idx + 1) % len(waveforms)]
        return self.waveform

    def toggle_mute(self):
        self.is_muted = not self.is_muted
        return self.is_muted

# ---------------------------------------------------------
# MAIN PROGRAM
# ---------------------------------------------------------
def main():
    print("==================================================")
    print("            Webcam Theremin Starting             ")
    print("==================================================")

    # Parse Command Line Arguments for Key (if any)
    user_key = None
    if len(sys.argv) > 1:
        try:
            parser = argparse.ArgumentParser(description="Webcam Theremin")
            parser.add_argument('--key', type=str, default=None, help="Starting root key (e.g. C, G, D)")
            parsed_args, _ = parser.parse_known_args()
            if parsed_args.key:
                user_key = parsed_args.key.strip().upper()
        except Exception:
            pass

    # Resolve active index on the Circle of Fifths
    active_idx = 0
    if user_key:
        resolved_key = KEY_ALIASES.get(user_key, 'C')
        for idx, item in enumerate(CIRCLE_OF_FIFTHS):
            if item['key'] == resolved_key:
                active_idx = idx
                break

    print(f"Starting Scale: {CIRCLE_OF_FIFTHS[active_idx]['name']}")
    print("Instructions:")
    print("  - Place your hand in front of the camera.")
    print("  - Move hand Left <-> Right to control Pitch.")
    print("  - Move hand Up <-> Down to control Volume.")
    print("  - Press 'W' to toggle Waveform.")
    print("  - Press 'S' or Right Arrow to go Clockwise on the Circle of Fifths.")
    print("  - Press 'A' or Left Arrow to go Counter-Clockwise on the Circle of Fifths.")
    print("  - Press 'G' to toggle Gate Mode (Hold Spacebar to play vs Always On).")
    print("  - Press 'M' to toggle Mute.")
    print("  - Press 'Q' or 'Esc' to Quit.")
    print("==================================================")

    # Model file downloading for MediaPipe Tasks
    model_filename = 'hand_landmarker.task'
    model_url = 'https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task'
    
    if not os.path.exists(model_filename):
        print(f"Downloading hand tracking model ({model_filename})...")
        try:
            def reporthook(blocknum, blocksize, totalsize):
                readsofar = blocknum * blocksize
                if totalsize > 0:
                    percent = readsofar * 1e2 / totalsize
                    s = f"\rProgress: {percent:5.1f}% [{readsofar}/{totalsize} bytes]"
                    sys.stdout.write(s)
                    sys.stdout.flush()
                else:
                    sys.stdout.write(f"\rDownloaded {readsofar} bytes")
                    sys.stdout.flush()
            urllib.request.urlretrieve(model_url, model_filename, reporthook)
            print("\nDownload complete.")
        except Exception as e:
            print(f"\nError downloading hand tracking model: {e}", file=sys.stderr)
            sys.exit(1)

    # Initialize audio synthesizer
    synth = AudioSynthesizer()
    try:
        synth.start()
    except Exception as e:
        print(f"Error starting audio device: {e}", file=sys.stderr)
        print("Please ensure you have a working audio output device enabled.", file=sys.stderr)
        sys.exit(1)

    # Configure MediaPipe Tasks Hand Landmarker
    BaseOptions = mp.tasks.BaseOptions
    HandLandmarker = mp.tasks.vision.HandLandmarker
    HandLandmarkerOptions = mp.tasks.vision.HandLandmarkerOptions
    VisionRunningMode = mp.tasks.vision.RunningMode

    options = HandLandmarkerOptions(
        base_options=BaseOptions(model_asset_path=model_filename),
        running_mode=VisionRunningMode.VIDEO,
        num_hands=1,
        min_hand_detection_confidence=0.7,
        min_hand_presence_confidence=0.7,
        min_tracking_confidence=0.7
    )

    # Open webcam using DirectShow on Windows to prevent freezes
    if sys.platform.startswith('win'):
        cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)
    else:
        cap = cv2.VideoCapture(0)
        
    # Configure camera resolution
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)

    if not cap.isOpened():
        print("Error: Could not open webcam.", file=sys.stderr)
        synth.stop()
        sys.exit(1)

    # Configure window
    cv2.namedWindow(WINDOW_NAME, cv2.WINDOW_NORMAL)
    cv2.resizeWindow(WINDOW_NAME, 960, 720)

    # Queue to store trailing hand cursor coordinates for drawing
    trail = collections.deque(maxlen=TRAIL_LENGTH)
    
    # State tracking variables
    target_freq = 440.0
    target_vol = 0.0
    hand_active = False
    gate_mode = True # Default to Gate Mode (Hold Space to Play) as requested

    # Standard hand skeleton connections
    connections = [
        (0, 1), (1, 2), (2, 3), (3, 4),      # Thumb
        (0, 5), (5, 6), (6, 7), (7, 8),      # Index
        (9, 10), (10, 11), (11, 12),         # Middle
        (13, 14), (14, 15), (15, 16),        # Ring
        (17, 18), (18, 19), (19, 20),        # Pinky
        (5, 9), (9, 13), (13, 17), (0, 17)   # Palm
    ]

    with HandLandmarker.create_from_options(options) as landmarker:
        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                print("Failed to grab webcam frame.", file=sys.stderr)
                break

            # Mirror frame horizontally for intuitive play
            frame = cv2.flip(frame, 1)
            h, w, c = frame.shape

            # Convert frame to RGB for MediaPipe
            rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            mp_image = mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb_frame)

            # Perform hand detection
            timestamp_ms = int(time.perf_counter() * 1000)
            results = landmarker.detect_for_video(mp_image, timestamp_ms)

            hand_detected = len(results.hand_landmarks) > 0

            # Copy frame for drawing semi-transparent overlays
            overlay = frame.copy()

            # Active scale parameters
            active_scale_item = CIRCLE_OF_FIFTHS[active_idx]
            root_pitch_class = active_scale_item['pitch_class']

            # Determine spacebar state (Virtual key code for Space is 0x20)
            space_pressed = False
            if sys.platform.startswith('win'):
                try:
                    space_pressed = (ctypes.windll.user32.GetAsyncKeyState(0x20) & 0x8000) != 0
                except Exception:
                    space_pressed = True # Fallback if win32 call errors
            else:
                space_pressed = True # Fallback for non-Windows platforms

            # Sound gate status: play only if either gate is off, or gate is on and space is pressed
            sound_trigger_active = (not gate_mode) or space_pressed

            # ---------------------------------------------------------
            # DRAW DYNAMIC GRID & LABELS
            # ---------------------------------------------------------
            for i in range(1, 5):
                y_line = int(h * i / 5)
                vol_val = int((1.0 - (i / 5)) * 100)
                cv2.line(overlay, (0, y_line), (w, y_line), (80, 80, 80), 1)
                cv2.putText(overlay, f"{vol_val}% Vol", (15, y_line - 5), 
                            cv2.FONT_HERSHEY_SIMPLEX, 0.4, (160, 160, 160), 1, cv2.LINE_AA)

            scale_notes = get_scale_notes(root_pitch_class)
            for n in scale_notes:
                f = 440.0 * (2.0 ** ((n - 69) / 12.0))
                norm_x = math.log(f / PITCH_MIN) / math.log(PITCH_MAX / PITCH_MIN)
                if 0.0 <= norm_x <= 1.0:
                    x_line = int(w * norm_x)
                    
                    is_root = (n % 12 == root_pitch_class)
                    if is_root:
                        line_color = (255, 255, 0) # Neon Cyan
                        line_thickness = 2
                        text_color = (255, 255, 255)
                    else:
                        line_color = (60, 60, 60) # Dim grey
                        line_thickness = 1
                        text_color = (130, 130, 130)
                        
                    cv2.line(overlay, (x_line, 0), (x_line, h), line_color, line_thickness)
                    
                    note_str = freq_to_note(f)
                    cv2.putText(overlay, note_str, (x_line + 5, h - 15), 
                                cv2.FONT_HERSHEY_SIMPLEX, 0.45 if is_root else 0.35, text_color, 1, cv2.LINE_AA)

            # Apply grid overlay
            cv2.addWeighted(overlay, 0.4, frame, 0.6, 0, frame)

            # ---------------------------------------------------------
            # PROCESS HAND LANDMARKS & AUDIO CONTROLS
            # ---------------------------------------------------------
            if hand_detected:
                hand_landmarks = results.hand_landmarks[0]
                
                # Draw custom neon hand skeleton lines
                for start_idx, end_idx in connections:
                    pt1_lm = hand_landmarks[start_idx]
                    pt2_lm = hand_landmarks[end_idx]
                    pt1 = (int(pt1_lm.x * w), int(pt1_lm.y * h))
                    pt2 = (int(pt2_lm.x * w), int(pt2_lm.y * h))
                    cv2.line(frame, pt1, pt2, (180, 255, 100), 2, cv2.LINE_AA) # Greenish neon lines
                
                # Draw joint points
                for lm in hand_landmarks:
                    pt = (int(lm.x * w), int(lm.y * h))
                    cv2.circle(frame, pt, 4, (255, 255, 255), -1)
                    cv2.circle(frame, pt, 5, (100, 200, 50), 1, cv2.LINE_AA)

                # Track Index Finger Tip
                index_tip = hand_landmarks[8]
                hx = int(index_tip.x * w)
                hy = int(index_tip.y * h)

                # Clamp coordinates to bounds
                index_tip_x = max(0.0, min(1.0, index_tip.x))
                index_tip_y = max(0.0, min(1.0, index_tip.y))

                trail.append((hx, hy))

                # Map X (0 to 1) logarithmically to Frequency Range
                raw_freq = PITCH_MIN * ((PITCH_MAX / PITCH_MIN) ** index_tip_x)
                
                # Snap instantly to scale (pitch quantization)
                target_freq = quantize_frequency(raw_freq, root_pitch_class)
                
                # Map Y (0 to 1) linearly to Volume (only active if sound trigger is active)
                if sound_trigger_active:
                    target_vol = 1.0 - index_tip_y
                    hand_active = True
                else:
                    target_vol = 0.0
                    hand_active = False
            else:
                # Smoothly fade to silence if no hand is detected
                target_vol = 0.0
                hand_active = False
                if len(trail) > 0:
                    trail.popleft()

            # Update audio synthesizer parameters
            # Instant frequency snapping prevents playing out-of-scale notes
            synth.frequency = target_freq
            synth.volume = synth.volume * (1.0 - SMOOTH_FACTOR) + target_vol * SMOOTH_FACTOR

            # ---------------------------------------------------------
            # DRAW MOTION TRAIL & HAND CURSOR
            # ---------------------------------------------------------
            for idx, pt in enumerate(trail):
                alpha = (idx + 1) / len(trail)
                radius = int(5 + 10 * alpha)
                color = (int(255 * alpha), int(255 * alpha), int(50 * (1 - alpha)))
                cv2.circle(frame, pt, radius, color, -1)

            if hand_detected and len(trail) > 0:
                current_pt = trail[-1]
                cv2.circle(frame, current_pt, 12, (255, 255, 255), 2, cv2.LINE_AA)
                cv2.circle(frame, current_pt, 4, (0, 255, 255), -1)

            # ---------------------------------------------------------
            # HUD / INSTRUMENT STATUS INTERFACE (Glassmorphism look)
            # ---------------------------------------------------------
            panel = frame.copy()
            # Left Panel (Settings / Controls)
            cv2.rectangle(panel, (10, 10), (325, 140), (30, 20, 20), -1)
            # Right Panel (Theremin status)
            cv2.rectangle(panel, (w - 325, 10), (w - 10, 140), (20, 30, 20), -1)
            # Help Bar at bottom
            cv2.rectangle(panel, (10, h - 45), (w - 10, h - 10), (25, 25, 25), -1)
            cv2.addWeighted(panel, 0.7, frame, 0.3, 0, frame)

            # Add HUD Text (Left Panel)
            cv2.putText(frame, "WEBCAM THEREMIN", (20, 32), 
                        cv2.FONT_HERSHEY_SIMPLEX, 0.65, (0, 255, 255), 2, cv2.LINE_AA)
            
            status_color = (0, 255, 100) if hand_detected else (0, 0, 255)
            status_text = "HAND ACTIVE" if hand_detected else "SEARCHING HAND..."
            cv2.putText(frame, f"Status: {status_text}", (20, 55), 
                        cv2.FONT_HERSHEY_SIMPLEX, 0.45, status_color, 1, cv2.LINE_AA)
            
            waveform_str = synth.waveform.upper()
            cv2.putText(frame, f"Waveform: {waveform_str}", (20, 73), 
                        cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255, 255, 255), 1, cv2.LINE_AA)
            
            scale_disp_str = active_scale_item['name'].upper()
            cv2.putText(frame, f"Key/Scale: {scale_disp_str}", (20, 91), 
                        cv2.FONT_HERSHEY_SIMPLEX, 0.42, (100, 200, 255), 1, cv2.LINE_AA)
            
            trigger_mode_str = "GATE (HOLD SPACE)" if gate_mode else "ALWAYS ON"
            cv2.putText(frame, f"Trigger Mode: {trigger_mode_str}", (20, 109), 
                        cv2.FONT_HERSHEY_SIMPLEX, 0.42, (240, 240, 240), 1, cv2.LINE_AA)

            mute_str = "MUTED" if synth.is_muted else "UNMUTED"
            mute_color = (0, 0, 255) if synth.is_muted else (0, 255, 100)
            cv2.putText(frame, f"Audio Mode: {mute_str}", (20, 127), 
                        cv2.FONT_HERSHEY_SIMPLEX, 0.4, mute_color, 1, cv2.LINE_AA)

            # Add HUD Text (Right Panel)
            cv2.putText(frame, "INSTRUMENT FEEDBACK", (w - 315, 32), 
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (100, 255, 100), 2, cv2.LINE_AA)
            
            note_name = freq_to_note(synth.current_frequency)
            cv2.putText(frame, f"Frequency: {synth.current_frequency:.1f} Hz", (w - 315, 55), 
                        cv2.FONT_HERSHEY_SIMPLEX, 0.45, (240, 240, 240), 1, cv2.LINE_AA)
            cv2.putText(frame, f"Note Pitch: {note_name}", (w - 315, 73), 
                        cv2.FONT_HERSHEY_SIMPLEX, 0.45, (240, 240, 240), 1, cv2.LINE_AA)
            
            vol_percentage = int(synth.current_volume * 100)
            cv2.putText(frame, f"Volume: {vol_percentage}%", (w - 315, 91), 
                        cv2.FONT_HERSHEY_SIMPLEX, 0.45, (240, 240, 240), 1, cv2.LINE_AA)

            # Draw Trigger/Gate status in Right Panel
            gate_status_str = "OPEN (PLAYING)" if sound_trigger_active else "CLOSED (MUTED)"
            gate_status_color = (0, 255, 100) if sound_trigger_active else (150, 150, 150)
            cv2.putText(frame, f"Gate State: {gate_status_str}", (w - 315, 115), 
                        cv2.FONT_HERSHEY_SIMPLEX, 0.45, gate_status_color, 1, cv2.LINE_AA)

            # Add Help Bar Text
            cv2.putText(frame, "[W] Waveform | [A/S] Shift Key | [G] Toggle Gate Mode | [M] Mute | [Q/ESC] Quit", 
                        (w // 2 - 305, h - 22), cv2.FONT_HERSHEY_SIMPLEX, 0.42, (200, 200, 200), 1, cv2.LINE_AA)

            # ---------------------------------------------------------
            # DRAW CIRCLE OF FIFTHS WHEEL
            # ---------------------------------------------------------
            wheel_cx = w - 75
            wheel_cy = 230
            wheel_r = 45
            
            cv2.circle(frame, (wheel_cx, wheel_cy), wheel_r, (60, 60, 60), 1, cv2.LINE_AA)
            
            for idx, item in enumerate(CIRCLE_OF_FIFTHS):
                theta = idx * (2.0 * math.pi / 12.0) - math.pi / 2.0
                tx = wheel_cx + int(wheel_r * math.cos(theta))
                ty = wheel_cy + int(wheel_r * math.sin(theta))
                
                key_text = item['key']
                
                if idx == active_idx:
                    cv2.circle(frame, (tx, ty), 12, (255, 255, 0), -1, cv2.LINE_AA) # Cyan fill
                    cv2.putText(frame, key_text, (tx - 5 if len(key_text)==1 else tx - 8, ty + 4),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.35, (0, 0, 0), 1, cv2.LINE_AA)
                else:
                    cv2.circle(frame, (tx, ty), 8, (35, 30, 30), -1, cv2.LINE_AA)
                    cv2.putText(frame, key_text, (tx - 4 if len(key_text)==1 else tx - 6, ty + 3),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.28, (200, 200, 200), 1, cv2.LINE_AA)

            # Show Frame
            cv2.imshow(WINDOW_NAME, frame)

            # Keyboard event handler
            # Flush OpenCV event queue to avoid hangs when holding keys (like Spacebar)
            pressed_keys = []
            while True:
                k = cv2.waitKey(1)
                if k == -1:
                    break
                pressed_keys.append(k & 0xFF)
            
            should_exit = False
            if pressed_keys:
                unique_keys = list(set(pressed_keys))
                for key in unique_keys:
                    if key == ord('q') or key == 27:
                        should_exit = True
                        break
                    elif key == ord('w'):
                        new_wave = synth.toggle_waveform()
                        print(f"Waveform toggled to: {new_wave}")
                    elif key in [ord('s'), 83, 39]: # Note: after & 0xFF, Windows virtual key codes fit within 0-255
                        active_idx = (active_idx + 1) % 12
                        print(f"Scale shifted clockwise to: {CIRCLE_OF_FIFTHS[active_idx]['name']}")
                    elif key in [ord('a'), 81, 37]:
                        active_idx = (active_idx - 1) % 12
                        print(f"Scale shifted counter-clockwise to: {CIRCLE_OF_FIFTHS[active_idx]['name']}")
                    elif key == ord('g'):
                        gate_mode = not gate_mode
                        print(f"Gate Mode changed to: {'ON (Hold Space to Play)' if gate_mode else 'OFF (Always On)'}")
                    elif key == ord('m'):
                        is_muted = synth.toggle_mute()
                        print(f"Mute status changed: {'MUTED' if is_muted else 'PLAYING'}")
            
            if should_exit:
                break

    # Cleanup
    print("Shutting down Webcam Theremin...")
    cap.release()
    cv2.destroyAllWindows()
    synth.stop()
    print("Goodbye!")

if __name__ == "__main__":
    main()
